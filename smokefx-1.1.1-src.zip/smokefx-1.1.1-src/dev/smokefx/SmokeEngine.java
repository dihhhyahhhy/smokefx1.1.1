package dev.smokefx;

import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.particles.ParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.tags.BlockTags;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.phys.AABB;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.IdentityHashMap;
import java.util.List;
import java.util.Map;

/**
 * SmokeFX 1.1: every heat source has its own particle "personality".
 *
 * Instead of random-sampling blocks, the engine sweeps one layer of the scan cube per tick and
 * caches every heat source it finds, so each torch/fire/furnace gets reliable, dense effects.
 */
public final class SmokeEngine {
    private SmokeEngine() {}

    private enum Kind {
        FIRE("fire"), SOUL_FIRE("soul_fire"),
        TORCH("torches"), SOUL_TORCH("soul_torches"), COPPER_TORCH("copper_torches"),
        CANDLE("candles"), CAMPFIRE("campfires"), SOUL_CAMPFIRE("soul_campfires"),
        FURNACE("furnaces"), BLAST_FURNACE("blast_furnaces"), SMOKER("smokers"),
        LAVA("lava"), MAGMA("magma"), LANTERN("lanterns");

        final String effect;
        Kind(String effect) { this.effect = effect; }
    }

    private static final class Source {
        final int x, y, z;
        final Kind kind;
        boolean dead;
        Source(int x, int y, int z, Kind kind) { this.x = x; this.y = y; this.z = z; this.kind = kind; }
    }

    private static final double NEAR = 12.0;

    private static final Map<Long, Source> SOURCES = new HashMap<>();
    private static List<Source> list = new ArrayList<>();
    private static boolean dirty = true;
    private static int layer = 0;
    private static ClientLevel lastLevel;

    private static final BlockPos.MutableBlockPos CURSOR = new BlockPos.MutableBlockPos();
    private static final BlockPos.MutableBlockPos CURSOR2 = new BlockPos.MutableBlockPos();

    // per-tick state
    private static ClientLevel level;
    private static RandomSource rng;
    private static int budget;
    private static double mult;
    private static double fall;

    // ------------------------------------------------------------------ tick

    public static void tick(Minecraft client) {
        SmokeFxConfig cfg = SmokeFxConfig.get();
        ClientLevel lvl = client.level;
        LocalPlayer player = client.player;
        if (!cfg.enabled || lvl == null || player == null || client.isPaused()) return;

        if (lvl != lastLevel) {
            SOURCES.clear();
            list = new ArrayList<>();
            dirty = true;
            lastLevel = lvl;
        }

        level = lvl;
        rng = lvl.getRandom();
        budget = cfg.maxParticlesPerTick;
        mult = cfg.particleMultiplier;
        int r = cfg.scanRadius;

        BlockPos origin = player.blockPosition();
        double px = player.getX(), py = player.getY(), pz = player.getZ();
        scanLayer(lvl, origin, r, px, py, pz);
        if (dirty) {
            list = new ArrayList<>(SOURCES.values());
            dirty = false;
        }

        int n = list.size();
        if (n > 0) {
            int start = rng.nextInt(n); // rotate start so far sources aren't starved by the budget
            double reach = r + 2.0;
            double reach2 = reach * reach;
            for (int i = 0; i < n && budget > 0; i++) {
                Source s = list.get((start + i) % n);
                if (s.dead) continue;
                double dx = s.x + 0.5 - px, dy = s.y + 0.5 - py, dz = s.z + 0.5 - pz;
                double d2 = dx * dx + dy * dy + dz * dz;
                if (d2 > reach2) { drop(s); continue; }
                if (!cfg.isEffectEnabled(s.kind.effect)) continue;

                BlockState st = lvl.getBlockState(CURSOR.set(s.x, s.y, s.z));
                if (classify(lvl, st, s.x, s.y, s.z) != s.kind) { drop(s); continue; }

                double d = Math.sqrt(d2);
                fall = d < NEAR ? 1.0 : Math.max(0.3, 1.0 - (d - NEAR) / Math.max(1.0, r));
                spawn(s, st);
            }
        }

        if (cfg.isEffectEnabled("burning_entities") && budget > 0) {
            burning(lvl, player, cfg, px, py, pz, r);
        }
    }

    private static void drop(Source s) {
        s.dead = true;
        long key = BlockPos.asLong(s.x, s.y, s.z);
        if (SOURCES.get(key) == s) SOURCES.remove(key);
        dirty = true;
    }

    // ------------------------------------------------------------------ scanning

    /**
     * Sweeps one x-layer of the scan area per tick. Only blocks inside a sphere slightly smaller than the
     * drop distance in tick() are cached, so sources are never added just to be dropped again.
     */
    private static void scanLayer(ClientLevel lvl, BlockPos o, int r, double px, double py, double pz) {
        int span = r * 2 + 1;
        layer = (layer + 1) % span;
        final int x = o.getX() - r + layer;

        if (SOURCES.values().removeIf(s -> s.x == x)) dirty = true;

        double reach = r + 1.0;
        double dx = x + 0.5 - px;
        double remX = reach * reach - dx * dx;
        if (remX < 0) return;

        for (int z = o.getZ() - r; z <= o.getZ() + r; z++) {
            double dz = z + 0.5 - pz;
            double remZ = remX - dz * dz;
            if (remZ < 0) continue;
            double h = Math.sqrt(remZ);
            int y0 = (int) Math.ceil(py - h - 0.5);
            int y1 = (int) Math.floor(py + h - 0.5);
            for (int y = y0; y <= y1; y++) {
                BlockState st = lvl.getBlockState(CURSOR.set(x, y, z));
                if (st.isAir()) continue;
                Kind k = classify(lvl, st, x, y, z);
                if (k != null) {
                    SOURCES.put(BlockPos.asLong(x, y, z), new Source(x, y, z, k));
                    dirty = true;
                }
            }
        }
    }

    private static final Map<Block, Integer> LANTERN_KINDS = new IdentityHashMap<>();

    /**
     * 0 = not a lantern, 1 = lantern, 2 = soul lantern, 3 = copper lantern (any oxidation, waxed or not).
     * Worked out once per block type from its registry name, so new lantern variants are picked up
     * automatically and the per-block cost during scanning is a single map lookup.
     */
    private static int lanternKind(Block b) {
        Integer cached = LANTERN_KINDS.get(b);
        if (cached != null) return cached;
        var key = BuiltInRegistries.BLOCK.getKey(b);
        int kind = 0;
        if (key.getNamespace().equals("minecraft") && key.getPath().endsWith("lantern")) {
            String path = key.getPath();
            kind = path.contains("soul") ? 2 : path.contains("copper") ? 3 : 1;
        }
        LANTERN_KINDS.put(b, kind);
        return kind;
    }

    private static boolean lit(BlockState s) {
        return s.hasProperty(BlockStateProperties.LIT) && s.getValue(BlockStateProperties.LIT);
    }

    private static boolean airAbove(ClientLevel lvl, int x, int y, int z) {
        return lvl.getBlockState(CURSOR2.set(x, y + 1, z)).isAir();
    }

    private static Kind classify(ClientLevel lvl, BlockState s, int x, int y, int z) {
        if (s.isAir()) return null;
        if (s.is(Blocks.FIRE)) return Kind.FIRE;
        if (s.is(Blocks.SOUL_FIRE)) return Kind.SOUL_FIRE;
        if (s.is(Blocks.TORCH) || s.is(Blocks.WALL_TORCH)) return Kind.TORCH;
        if (s.is(Blocks.SOUL_TORCH) || s.is(Blocks.SOUL_WALL_TORCH)) return Kind.SOUL_TORCH;
        if (s.is(Blocks.COPPER_TORCH) || s.is(Blocks.COPPER_WALL_TORCH)) return Kind.COPPER_TORCH;
        if (s.is(Blocks.CAMPFIRE)) return lit(s) ? Kind.CAMPFIRE : null;
        if (s.is(Blocks.SOUL_CAMPFIRE)) return lit(s) ? Kind.SOUL_CAMPFIRE : null;
        if (s.is(BlockTags.CANDLES)) return lit(s) ? Kind.CANDLE : null;
        if (s.is(Blocks.FURNACE)) return lit(s) ? Kind.FURNACE : null;
        if (s.is(Blocks.BLAST_FURNACE)) return lit(s) ? Kind.BLAST_FURNACE : null;
        if (s.is(Blocks.SMOKER)) return lit(s) ? Kind.SMOKER : null;
        if (s.is(Blocks.LAVA)) return airAbove(lvl, x, y, z) ? Kind.LAVA : null;
        if (s.is(Blocks.MAGMA_BLOCK)) return airAbove(lvl, x, y, z) ? Kind.MAGMA : null;
        if (lanternKind(s.getBlock()) != 0) return Kind.LANTERN;
        return null;
    }

    // ------------------------------------------------------------------ helpers

    private static void emit(ParticleOptions t, double x, double y, double z, double vx, double vy, double vz) {
        if (budget <= 0) return;
        budget--;
        level.addParticle(t, x, y, z, vx, vy, vz);
    }

    /** Expected-value based count: 0.35 means "about one particle every three ticks". */
    private static int count(double expected) {
        double v = expected * mult * fall;
        int n = (int) v;
        if (rng.nextDouble() < v - n) n++;
        return n;
    }

    private static double rn() { return rng.nextDouble(); }
    private static double j(double width) { return (rng.nextDouble() - 0.5) * width; }

    // ------------------------------------------------------------------ per-kind effects

    private static void spawn(Source s, BlockState st) {
        switch (s.kind) {
            case FIRE -> fire(s.x, s.y, s.z);
            case SOUL_FIRE -> soulFire(s.x, s.y, s.z);
            case TORCH -> torch(s, st, ParticleTypes.SMALL_FLAME, ParticleTypes.SMOKE, ParticleTypes.FLAME);
            case SOUL_TORCH -> torch(s, st, ParticleTypes.SOUL_FIRE_FLAME, ParticleTypes.SOUL, ParticleTypes.END_ROD);
            case COPPER_TORCH -> torch(s, st, ParticleTypes.COPPER_FIRE_FLAME, ParticleTypes.SMOKE, ParticleTypes.ELECTRIC_SPARK);
            case CANDLE -> candle(s.x, s.y, s.z);
            case CAMPFIRE -> campfire(s.x, s.y, s.z, false);
            case SOUL_CAMPFIRE -> campfire(s.x, s.y, s.z, true);
            case FURNACE -> furnaceLike(s, st, 0.30, 0.22, 0.08, 0.04, 0.16, 0.03, 0.00, 0.00);
            case BLAST_FURNACE -> furnaceLike(s, st, 0.55, 0.20, 0.20, 0.10, 0.22, 0.10, 0.06, 0.00);
            case SMOKER -> furnaceLike(s, st, 0.12, 0.30, 0.00, 0.00, 0.05, 0.00, 0.00, 0.24);
            case LAVA -> lava(s.x, s.y, s.z);
            case MAGMA -> magma(s.x, s.y, s.z);
            case LANTERN -> lantern(s.x, s.y, s.z, st);
        }
    }

    /** Wild, flickering fire: licking flames, rising smoke, popping embers and drifting ash. */
    private static void fire(int bx, int by, int bz) {
        double cx = bx + 0.5, cz = bz + 0.5;
        for (int i = count(0.45); i > 0; i--)
            emit(ParticleTypes.FLAME, cx + j(0.5), by + 0.1 + rn() * 0.7, cz + j(0.5), j(0.012), 0.015 + rn() * 0.025, j(0.012));
        for (int i = count(0.35); i > 0; i--)
            emit(ParticleTypes.SMOKE, cx + j(0.5), by + 0.8 + rn() * 0.4, cz + j(0.5), j(0.012), 0.03 + rn() * 0.03, j(0.012));
        for (int i = count(0.10); i > 0; i--)
            emit(ParticleTypes.LARGE_SMOKE, cx + j(0.4), by + 1.0, cz + j(0.4), j(0.01), 0.035 + rn() * 0.02, j(0.01));
        for (int i = count(0.14); i > 0; i--)
            emit(ParticleTypes.LAVA, cx + j(0.4), by + 0.4 + rn() * 0.4, cz + j(0.4), 0, 0, 0);
        for (int i = count(0.12); i > 0; i--)
            emit(ParticleTypes.ASH, cx + j(1.0), by + 0.6 + rn() * 0.6, cz + j(1.0), j(0.02), 0.01 + rn() * 0.02, j(0.02));
        if (rng.nextDouble() < 0.012 * mult * fall) { // occasional ember burst
            for (int i = 0; i < 5; i++) emit(ParticleTypes.LAVA, cx + j(0.3), by + 0.5, cz + j(0.3), 0, 0, 0);
        }
    }

    /** Ghostly: slow drifting souls, cold flame and white spirit motes. */
    private static void soulFire(int bx, int by, int bz) {
        double cx = bx + 0.5, cz = bz + 0.5;
        for (int i = count(0.45); i > 0; i--)
            emit(ParticleTypes.SOUL_FIRE_FLAME, cx + j(0.5), by + 0.1 + rn() * 0.7, cz + j(0.5), j(0.01), 0.02 + rn() * 0.03, j(0.01));
        for (int i = count(0.22); i > 0; i--)
            emit(ParticleTypes.SOUL, cx + j(0.6), by + 0.5 + rn() * 0.5, cz + j(0.6), j(0.01), 0.025 + rn() * 0.03, j(0.01));
        for (int i = count(0.07); i > 0; i--)
            emit(ParticleTypes.END_ROD, cx + j(0.7), by + 0.4 + rn() * 0.8, cz + j(0.7), j(0.006), 0.012 + rn() * 0.015, j(0.006));
    }

    /**
     * Shared by normal, soul and copper torches. Wall torches are offset to the real flame position.
     * A thin wisp rises from the flame and a rare spark pops upward.
     */
    private static void torch(Source s, BlockState st, ParticleOptions flame, ParticleOptions wisp,
                              ParticleOptions spark) {
        double fx = s.x + 0.5, fy = s.y + 0.7, fz = s.z + 0.5;
        if (st.hasProperty(BlockStateProperties.HORIZONTAL_FACING)) {
            Direction o = st.getValue(BlockStateProperties.HORIZONTAL_FACING).getOpposite();
            fx += 0.27 * o.getStepX();
            fz += 0.27 * o.getStepZ();
            fy += 0.22;
        }
        for (int i = count(0.28); i > 0; i--)
            emit(flame, fx + j(0.08), fy + j(0.05), fz + j(0.08), j(0.004), 0.004 + rn() * 0.006, j(0.004));
        for (int i = count(0.18); i > 0; i--)
            emit(wisp, fx + j(0.06), fy + 0.12, fz + j(0.06), j(0.004), 0.03 + rn() * 0.02, j(0.004));
        for (int i = count(0.06); i > 0; i--)
            emit(spark, fx + j(0.05), fy + 0.05, fz + j(0.05), j(0.03), 0.04 + rn() * 0.04, j(0.03));
    }

    /** Delicate: a tiny flame and a very thin curl of smoke. */
    private static void candle(int bx, int by, int bz) {
        double cx = bx + 0.5, cz = bz + 0.5;
        for (int i = count(0.14); i > 0; i--)
            emit(ParticleTypes.SMALL_FLAME, cx + j(0.12), by + 0.55 + j(0.04), cz + j(0.12), 0, 0.003, 0);
        for (int i = count(0.09); i > 0; i--)
            emit(ParticleTypes.SMOKE, cx + j(0.08), by + 0.7, cz + j(0.08), j(0.002), 0.018 + rn() * 0.012, j(0.002));
    }

    /**
     * Campfire: a fat smoke column (signal smoke above hay), flames, a shower of embers and ash.
     * Soul campfire swaps in soul flame, souls and spirit motes.
     */
    private static void campfire(int bx, int by, int bz, boolean soul) {
        double cx = bx + 0.5, cz = bz + 0.5;
        if (soul) {
            for (int i = count(0.40); i > 0; i--)
                emit(ParticleTypes.SOUL_FIRE_FLAME, cx + j(0.5), by + 0.2 + rn() * 0.4, cz + j(0.5), j(0.01), 0.03 + rn() * 0.03, j(0.01));
            for (int i = count(0.24); i > 0; i--)
                emit(ParticleTypes.SOUL, cx + j(0.5), by + 0.6 + rn() * 0.4, cz + j(0.5), j(0.01), 0.035 + rn() * 0.03, j(0.01));
            for (int i = count(0.08); i > 0; i--)
                emit(ParticleTypes.END_ROD, cx + j(0.6), by + 0.6 + rn() * 0.6, cz + j(0.6), j(0.008), 0.02 + rn() * 0.02, j(0.008));
            for (int i = count(0.06); i > 0; i--)
                emit(ParticleTypes.CAMPFIRE_COSY_SMOKE, cx + j(0.4), by + 0.55, cz + j(0.4), j(0.004), 0.06 + rn() * 0.02, j(0.004));
            return;
        }
        boolean hay = level.getBlockState(CURSOR2.set(bx, by - 1, bz)).is(Blocks.HAY_BLOCK);
        for (int i = count(0.14); i > 0; i--)
            emit(ParticleTypes.CAMPFIRE_COSY_SMOKE, cx + j(0.5), by + 0.55, cz + j(0.5), j(0.004), 0.07 + rn() * 0.02, j(0.004));
        if (hay) {
            for (int i = count(0.10); i > 0; i--)
                emit(ParticleTypes.CAMPFIRE_SIGNAL_SMOKE, cx + j(0.4), by + 0.6, cz + j(0.4), j(0.004), 0.09 + rn() * 0.02, j(0.004));
        }
        for (int i = count(0.40); i > 0; i--)
            emit(ParticleTypes.FLAME, cx + j(0.55), by + 0.15 + rn() * 0.4, cz + j(0.55), j(0.01), 0.025 + rn() * 0.03, j(0.01));
        for (int i = count(0.25); i > 0; i--)
            emit(ParticleTypes.LAVA, cx + j(0.5), by + 0.4, cz + j(0.5), 0, 0, 0);
        for (int i = count(0.10); i > 0; i--)
            emit(ParticleTypes.ASH, cx + j(1.0), by + 0.8 + rn() * 0.6, cz + j(1.0), j(0.02), 0.012 + rn() * 0.02, j(0.02));
    }

    /**
     * Furnace family. Flames/sparks spit out of the front opening, smoke leaves the top.
     * Weights: flame, openingSmoke, sparkFlame, lavaSpark, topSmoke, topLargeSmoke, ash, topCosySmoke.
     */
    private static void furnaceLike(Source s, BlockState st, double flame, double openSmoke, double spark,
                                    double lavaSpark, double topSmoke, double topLarge, double ash, double cosy) {
        Direction f = st.hasProperty(BlockStateProperties.HORIZONTAL_FACING)
            ? st.getValue(BlockStateProperties.HORIZONTAL_FACING) : Direction.NORTH;
        double fx = f.getStepX(), fz = f.getStepZ();
        double cx = s.x + 0.5, cz = s.z + 0.5;
        double ox = cx + fx * 0.53, oz = cz + fz * 0.53;
        double sx = Math.abs(fz), sz = Math.abs(fx); // sideways axis along the face

        for (int i = count(flame); i > 0; i--)
            emit(ParticleTypes.FLAME, ox + sx * j(0.55), s.y + 0.1 + rn() * 0.3, oz + sz * j(0.55), fx * 0.02, 0.01, fz * 0.02);
        for (int i = count(openSmoke); i > 0; i--)
            emit(ParticleTypes.SMOKE, ox + sx * j(0.55), s.y + 0.2 + rn() * 0.2, oz + sz * j(0.55), fx * 0.02, 0.025, fz * 0.02);
        for (int i = count(spark); i > 0; i--)
            emit(ParticleTypes.FLAME, ox, s.y + 0.2, oz, fx * 0.07 + j(0.03), 0.05 + rn() * 0.04, fz * 0.07 + j(0.03));
        for (int i = count(lavaSpark); i > 0; i--)
            emit(ParticleTypes.LAVA, ox, s.y + 0.2, oz, 0, 0, 0);
        for (int i = count(topSmoke); i > 0; i--)
            emit(ParticleTypes.SMOKE, cx + j(0.4), s.y + 1.02, cz + j(0.4), j(0.006), 0.04 + rn() * 0.025, j(0.006));
        for (int i = count(topLarge); i > 0; i--)
            emit(ParticleTypes.LARGE_SMOKE, cx + j(0.4), s.y + 1.05, cz + j(0.4), j(0.006), 0.035 + rn() * 0.02, j(0.006));
        for (int i = count(cosy); i > 0; i--)
            emit(ParticleTypes.CAMPFIRE_COSY_SMOKE, cx + j(0.4), s.y + 1.02, cz + j(0.4), j(0.004), 0.06 + rn() * 0.02, j(0.004));
        for (int i = count(ash); i > 0; i--)
            emit(ParticleTypes.ASH, cx + j(0.8), s.y + 1.1 + rn() * 0.5, cz + j(0.8), j(0.02), 0.015 + rn() * 0.02, j(0.02));
    }

    /** Molten surface: high-arcing sparks, bubble-pop puffs, heat smoke and small flame licks. */
    private static void lava(int bx, int by, int bz) {
        double x = bx + rn(), z = bz + rn(), y = by + 0.9;
        for (int i = count(0.07); i > 0; i--)
            emit(ParticleTypes.LAVA, x, y, z, 0, 0, 0);
        for (int i = count(0.07); i > 0; i--)
            emit(ParticleTypes.SMOKE, x, y + 0.1, z, j(0.01), 0.03 + rn() * 0.03, j(0.01));
        for (int i = count(0.025); i > 0; i--)
            emit(ParticleTypes.LARGE_SMOKE, x, y + 0.2, z, j(0.01), 0.04 + rn() * 0.02, j(0.01));
        for (int i = count(0.07); i > 0; i--)
            emit(ParticleTypes.FLAME, x, y + 0.05, z, j(0.01), 0.02 + rn() * 0.02, j(0.01));
        for (int i = count(0.03); i > 0; i--)
            emit(ParticleTypes.ASH, x, y + 0.4, z, j(0.02), 0.02 + rn() * 0.02, j(0.02));
    }

    /** Cooling crust: faint heat wisps and the odd spark. */
    private static void magma(int bx, int by, int bz) {
        double x = bx + rn(), z = bz + rn(), y = by + 1.02;
        for (int i = count(0.05); i > 0; i--)
            emit(ParticleTypes.SMOKE, x, y, z, j(0.004), 0.02 + rn() * 0.02, j(0.004));
        for (int i = count(0.012); i > 0; i--)
            emit(ParticleTypes.LAVA, x, y, z, 0, 0, 0);
        for (int i = count(0.025); i > 0; i--)
            emit(ParticleTypes.ASH, x, y + 0.3, z, j(0.01), 0.015 + rn() * 0.015, j(0.01));
    }

    /** Subtle glow flicker inside the cage; soul lanterns release a faint soul, copper ones burn green. */
    private static void lantern(int bx, int by, int bz, BlockState st) {
        double cx = bx + 0.5, cz = bz + 0.5;
        int kind = lanternKind(st.getBlock());
        ParticleOptions flame = kind == 2 ? ParticleTypes.SOUL_FIRE_FLAME
            : kind == 3 ? ParticleTypes.COPPER_FIRE_FLAME : ParticleTypes.SMALL_FLAME;
        for (int i = count(0.06); i > 0; i--)
            emit(flame, cx + j(0.12), by + 0.35 + j(0.08), cz + j(0.12), 0, 0.002, 0);
        if (kind == 2) {
            for (int i = count(0.03); i > 0; i--)
                emit(ParticleTypes.SOUL, cx + j(0.2), by + 0.6, cz + j(0.2), 0, 0.02, 0);
        } else {
            for (int i = count(0.02); i > 0; i--)
                emit(ParticleTypes.SMOKE, cx + j(0.1), by + 0.7, cz + j(0.1), 0, 0.02, 0);
        }
    }

    // ------------------------------------------------------------------ burning entities

    private static void burning(ClientLevel lvl, LocalPlayer player, SmokeFxConfig cfg,
                                double px, double py, double pz, int r) {
        AABB box = player.getBoundingBox().inflate(r);
        for (Entity e : lvl.getEntities(player, box)) {
            if (budget <= 0) return;
            burnOne(e, px, py, pz, r);
        }
        if (cfg.affectLocalPlayer && budget > 0) burnOne(player, px, py, pz, r);
    }

    /** Fire hugging the body, trailing smoke, embers shed downward, ash from the top. Scales with mob size. */
    private static void burnOne(Entity e, double px, double py, double pz, int r) {
        if (e.isRemoved() || !e.isOnFire()) return;
        double dx = e.getX() - px, dy = e.getY() - py, dz = e.getZ() - pz;
        double d = Math.sqrt(dx * dx + dy * dy + dz * dz);
        fall = d < NEAR ? 1.0 : Math.max(0.3, 1.0 - (d - NEAR) / Math.max(1.0, r));

        double w = e.getBbWidth(), h = e.getBbHeight();
        double size = Math.min(3.0, Math.sqrt(Math.max(0.05, w * h)));
        double x = e.getX(), y = e.getY(), z = e.getZ();

        for (int i = count(1.6 * size); i > 0; i--)
            emit(ParticleTypes.FLAME, x + j(w), y + rn() * h, z + j(w), j(0.02), 0.03 + rn() * 0.03, j(0.02));
        for (int i = count(0.7 * size); i > 0; i--)
            emit(ParticleTypes.SMOKE, x + j(w), y + h * (0.6 + rn() * 0.5), z + j(w), j(0.015), 0.04 + rn() * 0.03, j(0.015));
        for (int i = count(0.15 * size); i > 0; i--)
            emit(ParticleTypes.LARGE_SMOKE, x + j(w * 0.7), y + h * (0.9 + rn() * 0.3), z + j(w * 0.7), j(0.01), 0.04 + rn() * 0.02, j(0.01));
        for (int i = count(0.4 * size); i > 0; i--)
            emit(ParticleTypes.LAVA, x + j(w), y + rn() * h, z + j(w), 0, 0, 0);
        for (int i = count(0.12 * size); i > 0; i--)
            emit(ParticleTypes.ASH, x + j(w * 1.2), y + h * (0.5 + rn() * 0.6), z + j(w * 1.2), j(0.03), 0.01 + rn() * 0.02, j(0.03));
    }
}
