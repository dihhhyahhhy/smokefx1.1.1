package dev.smokefx;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.BoolArgumentType;
import com.mojang.brigadier.arguments.FloatArgumentType;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import net.fabricmc.fabric.api.client.command.v2.ClientCommands;
import net.fabricmc.fabric.api.client.command.v2.FabricClientCommandSource;
import net.minecraft.network.chat.Component;

public final class SmokeFxCommand {
    private SmokeFxCommand() {}

    public static void register(CommandDispatcher<FabricClientCommandSource> dispatcher) {
        LiteralArgumentBuilder<FabricClientCommandSource> root = ClientCommands.literal("smokefx")
            .executes(ctx -> status(ctx.getSource()));

        root.then(ClientCommands.literal("amount")
            .then(ClientCommands.argument("multiplier", FloatArgumentType.floatArg(0f, 5f))
                .executes(ctx -> {
                    SmokeFxConfig cfg = SmokeFxConfig.get();
                    cfg.particleMultiplier = FloatArgumentType.getFloat(ctx, "multiplier");
                    cfg.save();
                    return say(ctx.getSource(), "Particle amount set to " + cfg.particleMultiplier + "x.");
                })));

        root.then(ClientCommands.literal("radius")
            .then(ClientCommands.argument("blocks", IntegerArgumentType.integer(4, 64))
                .executes(ctx -> {
                    SmokeFxConfig cfg = SmokeFxConfig.get();
                    cfg.scanRadius = IntegerArgumentType.getInteger(ctx, "blocks");
                    cfg.save();
                    return say(ctx.getSource(), "Effect radius set to " + cfg.scanRadius + " blocks.");
                })));

        root.then(ClientCommands.literal("limit")
            .then(ClientCommands.argument("particles", IntegerArgumentType.integer(0, 5000))
                .executes(ctx -> {
                    SmokeFxConfig cfg = SmokeFxConfig.get();
                    cfg.maxParticlesPerTick = IntegerArgumentType.getInteger(ctx, "particles");
                    cfg.save();
                    return say(ctx.getSource(), "Particle limit set to " + cfg.maxParticlesPerTick + " per tick.");
                })));

        LiteralArgumentBuilder<FabricClientCommandSource> effect = ClientCommands.literal("effect");
        for (String name : SmokeFxConfig.EFFECTS) {
            effect.then(ClientCommands.literal(name)
                .executes(ctx -> setEffect(ctx.getSource(), name, !SmokeFxConfig.get().isEffectEnabled(name)))
                .then(ClientCommands.argument("enabled", BoolArgumentType.bool())
                    .executes(ctx -> setEffect(ctx.getSource(), name, BoolArgumentType.getBool(ctx, "enabled")))));
        }
        root.then(effect);

        root.then(ClientCommands.literal("enabled")
            .then(ClientCommands.argument("enabled", BoolArgumentType.bool())
                .executes(ctx -> {
                    SmokeFxConfig cfg = SmokeFxConfig.get();
                    cfg.enabled = BoolArgumentType.getBool(ctx, "enabled");
                    cfg.save();
                    return say(ctx.getSource(), cfg.enabled ? "SmokeFX enabled." : "SmokeFX disabled.");
                })));

        root.then(ClientCommands.literal("self")
            .executes(ctx -> setSelf(ctx.getSource(), !SmokeFxConfig.get().affectLocalPlayer))
            .then(ClientCommands.argument("enabled", BoolArgumentType.bool())
                .executes(ctx -> setSelf(ctx.getSource(), BoolArgumentType.getBool(ctx, "enabled")))));

        root.then(ClientCommands.literal("reload").executes(ctx -> {
            SmokeFxConfig.load();
            return say(ctx.getSource(), "Config reloaded.");
        }));

        root.then(ClientCommands.literal("save").executes(ctx -> {
            SmokeFxConfig.get().save();
            return say(ctx.getSource(), "Config saved.");
        }));

        root.then(ClientCommands.literal("status").executes(ctx -> status(ctx.getSource())));

        dispatcher.register(root);
    }

    private static int setEffect(FabricClientCommandSource src, String name, boolean value) {
        SmokeFxConfig cfg = SmokeFxConfig.get();
        cfg.setEffect(name, value);
        cfg.save();
        return say(src, "Effect '" + name + "' " + (value ? "enabled." : "disabled."));
    }

    private static int setSelf(FabricClientCommandSource src, boolean value) {
        SmokeFxConfig cfg = SmokeFxConfig.get();
        cfg.affectLocalPlayer = value;
        cfg.save();
        return say(src, "Fire effects on yourself " + (value ? "enabled." : "disabled."));
    }

    private static int status(FabricClientCommandSource src) {
        SmokeFxConfig cfg = SmokeFxConfig.get();
        StringBuilder off = new StringBuilder();
        for (String name : SmokeFxConfig.EFFECTS) {
            if (!cfg.isEffectEnabled(name)) {
                if (off.length() > 0) off.append(", ");
                off.append(name);
            }
        }
        return say(src, (cfg.enabled ? "ON" : "OFF")
            + " | amount " + cfg.particleMultiplier + "x"
            + " | radius " + cfg.scanRadius
            + " | limit " + cfg.maxParticlesPerTick + "/tick"
            + " | self " + (cfg.affectLocalPlayer ? "on" : "off")
            + " | disabled effects: " + (off.length() == 0 ? "none" : off));
    }

    private static int say(FabricClientCommandSource src, String msg) {
        src.sendFeedback(Component.literal("[SmokeFX] " + msg));
        return 1;
    }
}
