package dev.smokefx;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.LinkedHashMap;
import java.util.Map;

public final class SmokeFxConfig {
    /** Every toggleable effect. Must match the names used in SmokeEngine. */
    public static final String[] EFFECTS = {
        "fire", "soul_fire", "torches", "soul_torches", "copper_torches", "candles",
        "campfires", "soul_campfires", "furnaces", "blast_furnaces", "smokers",
        "lava", "magma", "lanterns", "burning_entities"
    };

    private static final int VERSION = 2;
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Path FILE = FabricLoader.getInstance().getConfigDir().resolve("smokefx.json");
    private static SmokeFxConfig instance = new SmokeFxConfig();

    /** Defaults to 1 on purpose: configs from 1.0.x have no version field and must count as old. */
    public int version = 1;
    public boolean enabled = true;
    public float particleMultiplier = 1.0f;
    public int scanRadius = 24;
    public int maxParticlesPerTick = 500;
    public boolean affectLocalPlayer = false;
    public Map<String, Boolean> effects = new LinkedHashMap<>();

    public static SmokeFxConfig get() {
        return instance;
    }

    public boolean isEffectEnabled(String name) {
        return effects.getOrDefault(name, true);
    }

    public void setEffect(String name, boolean value) {
        effects.put(name, value);
    }

    public static SmokeFxConfig load() {
        SmokeFxConfig loaded = null;
        if (Files.exists(FILE)) {
            try {
                loaded = GSON.fromJson(Files.readString(FILE), SmokeFxConfig.class);
            } catch (Exception e) {
                System.err.println("[SmokeFX] Could not read config, using defaults: " + e);
                backUpBrokenConfig();
            }
        }
        if (loaded == null) {
            loaded = new SmokeFxConfig();
        }
        // Configs from 1.0.x had much lower budgets; raise them for the richer effects,
        // but never lower a value the player already set higher.
        if (loaded.version < VERSION) {
            loaded.scanRadius = Math.max(loaded.scanRadius, 24);
            loaded.maxParticlesPerTick = Math.max(loaded.maxParticlesPerTick, 500);
            loaded.version = VERSION;
        }
        loaded.sanitize();
        loaded.save();
        instance = loaded;
        return loaded;
    }

    /** Keeps an unreadable config as smokefx.json.bak so a typo never destroys the player's settings. */
    private static void backUpBrokenConfig() {
        try {
            Path bak = FILE.resolveSibling("smokefx.json.bak");
            Files.move(FILE, bak, StandardCopyOption.REPLACE_EXISTING);
            System.err.println("[SmokeFX] The unreadable config was saved as " + bak.getFileName());
        } catch (IOException e) {
            System.err.println("[SmokeFX] Could not back up the broken config: " + e);
        }
    }

    private void sanitize() {
        particleMultiplier = Math.max(0f, Math.min(5f, particleMultiplier));
        scanRadius = Math.max(4, Math.min(64, scanRadius));
        maxParticlesPerTick = Math.max(0, Math.min(5000, maxParticlesPerTick));
        Map<String, Boolean> old = effects == null ? new LinkedHashMap<>() : effects;
        Map<String, Boolean> fresh = new LinkedHashMap<>();
        for (String name : EFFECTS) {
            fresh.put(name, old.getOrDefault(name, true));
        }
        effects = fresh;
    }

    public void save() {
        try {
            sanitize();
            Files.createDirectories(FILE.getParent());
            Files.writeString(FILE, GSON.toJson(this));
        } catch (IOException e) {
            System.err.println("[SmokeFX] Could not save config: " + e);
        }
    }
}
