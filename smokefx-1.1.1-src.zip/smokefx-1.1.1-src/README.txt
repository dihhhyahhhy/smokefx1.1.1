SmokeFX 1.1.1 source (drop-in replacement for 1.0.0 and 1.1.0)

INSTALL
1. In your project, replace the four files in  src/client/java/dev/smokefx/  with the ones in dev/smokefx/ here:
   SmokeEngine.java, SmokeFxConfig.java, SmokeFxCommand.java, SmokeFxClient.java
2. In gradle.properties set  mod_version=1.1.1  (the jar name and mod version come from there;
   fabric.mod.json just uses ${version}).
3. Build as usual (push to GitHub and download the smokefx-jar artifact).

CHANGES SINCE 1.1.0
- Fixed: old 1.0.x configs now really migrate (radius/limit are raised, but never lowered if you set them higher).
- Fixed: a config with a typo is saved as smokefx.json.bak instead of being overwritten with defaults.
- Copper torches now burn with the green copper flame. All copper lanterns (every oxidation stage, waxed or not)
  are supported and get the green flame; soul lanterns keep their soul effects.
- New command: /smokefx self [true|false]  - fire effects on your own burning character (also shown in /smokefx status).
- Scanning is clipped to a sphere, so the cache no longer adds sources that are immediately dropped.

NOTE: if the build fails on ParticleTypes.COPPER_FIRE_FLAME, tell me the error text and I'll adjust the name.
